package com.hexaware.serviceimplementation;

import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hexaware.customexceptions.AccountAlreadyExistsException;
import com.hexaware.customexceptions.ResourceNotFoundException;
import com.hexaware.dto.CustomerDto;
import com.hexaware.dto.LoanDTO;
import com.hexaware.entity.Customer;
import com.hexaware.entity.Loan;
//import com.hexaware.entity.User;
import com.hexaware.repository.CustomerRepository;
import com.hexaware.repository.LoanRepository;
//import com.hexaware.repository.UserRepository;
import com.hexaware.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService {
	private CustomerRepository customerRepo;
	@Autowired
	private ModelMapper modelMapper;
//	@Autowired
//	private UserRepository userRepo;

	public CustomerServiceImpl(CustomerRepository customerRepo) {
		super();
		this.customerRepo = customerRepo;
	}

	@Override
	public CustomerDto createCustomer(CustomerDto c) throws AccountAlreadyExistsException {
		// TODO Auto-generated method stub
		Customer obj = modelMapper.map(c, Customer.class);
		Customer returnedAadharNumber = customerRepo.findByAadharNumber(obj.getAadharNumber());
		if (returnedAadharNumber == null) {
			//User userObj=obj.getUser();
			//String password=userObj.getPassword();
			Customer savedobj = customerRepo.save(obj);
			customerRepo.save(savedobj);
			//userRepo.save(userObj);
			CustomerDto savedDtoobj = modelMapper.map(savedobj, CustomerDto.class);
			return savedDtoobj;
		} else
			throw new AccountAlreadyExistsException("Customer", "aadhar number", obj.getAadharNumber());

	}

	@Override
	public CustomerDto findCustomerByid(long id) throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		Optional<Customer> returnedObj = customerRepo.findById(id);
		if (returnedObj.isEmpty()) {
			throw new ResourceNotFoundException("Customer", "ID", id);
		} else {
			Customer obj=returnedObj.get();
			CustomerDto DtoObj=modelMapper.map(obj, CustomerDto.class);
			return DtoObj;
		}
	}
	/*
	 * @Override public void deleteCustomerById(long id) { // TODO Auto-generated
	 * method stub customerRepo.deleteById(id);
	 * 
	 * }
	 */
	public List<Customer> getAllCustomers() {
		return customerRepo.findAll();
	}

	@Override
	public List<Customer> findBycustomerNameContaining(String name) {
		// TODO Auto-generated method stub
		return customerRepo.findBycustomerNameContaining(name);
	}

	@Override
	public void deleteCustomerById(long id) {
		// TODO Auto-generated method stub
		customerRepo.deleteById(id);		
	}
}
