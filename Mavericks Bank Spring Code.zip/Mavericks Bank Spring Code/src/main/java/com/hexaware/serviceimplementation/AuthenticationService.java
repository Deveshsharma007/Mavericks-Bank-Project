/*package com.hexaware.serviceimplementation;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.hexaware.entity.AuthenticationResponse;
import com.hexaware.entity.User;
import com.hexaware.repository.UserRepository;



@Service
public class AuthenticationService {
	@Autowired
	private UserRepository userRepo;
	@Autowired
	private PasswordEncoder passwordEncoder;
	@Autowired
	private JwtServiceImpl jwtService;
	@Autowired
	private AuthenticationManager authenticationManager;
	
	
	public AuthenticationResponse register(User request)
	{
		User user=new User();
		user.setUserName(request.getUserName());
		user.setPassword(passwordEncoder.encode(request.getPassword()));
		user.setRole(request.getRole());
		user=userRepo.save(user);
		String token=jwtService.generateToken(user);
		return new AuthenticationResponse(token);
		
	}
	public AuthenticationResponse login(User request)
	{
		authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(request.getUserName(),request.getPassword()));
		User user=userRepo.findByuserName(request.getUserName());
		String token=jwtService.generateToken(user);
		return new AuthenticationResponse(token);
	}

}
*/