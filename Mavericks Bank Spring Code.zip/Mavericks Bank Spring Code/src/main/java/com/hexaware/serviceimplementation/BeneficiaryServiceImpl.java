package com.hexaware.serviceimplementation;

import java.util.Optional;
import java.util.stream.Collectors;
import java.util.List;


import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hexaware.customexceptions.ResourceNotFoundException;
import com.hexaware.dto.BeneficiaryAddDTO;
import com.hexaware.entity.Account;
import com.hexaware.entity.Beneficiary;
import com.hexaware.repository.AccountRepository;
import com.hexaware.repository.BeneficiaryRepository;
import com.hexaware.service.BeneficiaryService;
@Service
public class BeneficiaryServiceImpl implements BeneficiaryService{

	@Autowired
	private BeneficiaryRepository beneficiaryRepo;
	@Autowired
	private ModelMapper modelMapper;
	@Autowired
	private AccountRepository accountRepo;
	
	@Override
	public String addBeneficiary(long accountid,String bankname,String bankbranch,String bankifsccode,BeneficiaryAddDTO beneficiary) throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		Optional<Account> accountOpt=accountRepo.findById(accountid);
		if(accountOpt.isPresent()) {
		Account accountObj=accountOpt.get();
		List<Beneficiary> beneficiaryList=accountObj.getBeneficiary();
		Beneficiary obj=modelMapper.map(beneficiary,Beneficiary.class);
		obj.setBeneficiaryBankName(bankname);
		obj.setBeneficiaryBranch(bankbranch);
		obj.setBeneficiaryIfscCode(bankifsccode);
		obj.setAccount(accountObj);
		beneficiaryList.add(obj);
		accountObj.setBeneficiary(beneficiaryList);
		beneficiaryRepo.save(obj);
		return "Beneficiary Added Successfully";
		}
		else 
			throw new ResourceNotFoundException("Account", "number", accountid);
	}

	@Override
	public List<BeneficiaryAddDTO> getBeneficiary(long accountnumber) throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		Optional<Account> accountOpt=accountRepo.findById(accountnumber);
		if(accountOpt.isPresent()) {
		Account accountObj=accountOpt.get();
		List<Beneficiary> beneficiaryList=accountObj.getBeneficiary();
		return beneficiaryList.stream().map(bList->modelMapper.map(bList, BeneficiaryAddDTO.class)).collect(Collectors.toList());
		}
		else 
			throw new ResourceNotFoundException("Account", "number", accountnumber);	
	}
}
