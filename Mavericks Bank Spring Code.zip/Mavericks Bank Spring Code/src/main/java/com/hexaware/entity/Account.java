package com.hexaware.entity;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.hexaware.enums.AccountStatus;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="accounts")
public class Account {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long accountNumber;
	private String accountType;
	private double accountBalance;
	@Enumerated(EnumType.STRING)
	private AccountStatus accountStatus;
	@ManyToOne
	private Customer customer;
	@ManyToOne
    @JoinColumn(name = "bank_id")
    private Bank bank;
	
	@OneToMany(cascade=CascadeType.ALL)
	@JoinTable(name="beneficiary_account_mapping",joinColumns=@JoinColumn(name="account_id"),inverseJoinColumns=@JoinColumn(name="beneficiary_id"))
	private List<Beneficiary> beneficiary=new ArrayList<>();
	
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="bankEmployee_account_mapping",joinColumns=@JoinColumn(name="account_id"),inverseJoinColumns=@JoinColumn(name="employee_id"))
	private List<BankEmployee> bankEmployee=new ArrayList<>();
	
	@OneToMany(cascade=CascadeType.ALL)
	@JoinTable(name="account_loan_mapping",joinColumns=@JoinColumn(name="account_id"),inverseJoinColumns=@JoinColumn(name="loan_id"))
	private List<Loan> loanList=new ArrayList<>();
	
	@OneToMany(cascade=CascadeType.ALL)
	@JoinTable(name="account_transaction_mapping",joinColumns=@JoinColumn(name="account_id"),inverseJoinColumns=@JoinColumn(name="transaction_id"))
	private List<Transaction> transactionList=new ArrayList<>();

	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Account(long accountNumber, String accountType, double accountBalance, AccountStatus accountStatus,
			Customer customer, Bank bank, List<Beneficiary> beneficiary, List<BankEmployee> bankEmployee,
			List<Loan> loanList, List<Transaction> transactionList) {
		super();
		this.accountNumber = accountNumber;
		this.accountType = accountType;
		this.accountBalance = accountBalance;
		this.accountStatus = accountStatus;
		this.customer = customer;
		this.bank = bank;
		this.beneficiary = beneficiary;
		this.bankEmployee = bankEmployee;
		this.loanList = loanList;
		this.transactionList = transactionList;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	public AccountStatus getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(AccountStatus accountStatus) {
		this.accountStatus = accountStatus;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Bank getBank() {
		return bank;
	}

	public void setBank(Bank bank) {
		this.bank = bank;
	}

	public List<Beneficiary> getBeneficiary() {
		return beneficiary;
	}

	public void setBeneficiary(List<Beneficiary> beneficiary) {
		this.beneficiary = beneficiary;
	}

	public List<BankEmployee> getBankEmployee() {
		return bankEmployee;
	}

	public void setBankEmployee(List<BankEmployee> bankEmployee) {
		this.bankEmployee = bankEmployee;
	}

	public List<Loan> getLoanList() {
		return loanList;
	}

	public void setLoanList(List<Loan> loanList) {
		this.loanList = loanList;
	}

	public List<Transaction> getTransactionList() {
		return transactionList;
	}

	public void setTransactionList(List<Transaction> transactionList) {
		this.transactionList = transactionList;
	}

	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", accountType=" + accountType + ", accountBalance="
				+ accountBalance + ", accountStatus=" + accountStatus + ", customer=" + customer + ", bank=" + bank
				+ ", beneficiary=" + beneficiary + ", bankEmployee=" + bankEmployee + ", loanList=" + loanList
				+ ", transactionList=" + transactionList + "]";
	}
	
	

}
