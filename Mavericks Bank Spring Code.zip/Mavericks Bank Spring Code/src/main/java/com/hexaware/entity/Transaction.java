package com.hexaware.entity;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.hexaware.enums.TransactionType;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;


@Entity
@Table
public class Transaction {
	private LocalDate date;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long transactionID;
	@Enumerated(EnumType.STRING)
	private TransactionType transactionType;
	private double transactionAmount;
	private long beneficiaryAccountNumber;
	
	@ManyToOne()
	private Account account;
	
	@ManyToMany(mappedBy="transactionList")
	private List<BankEmployee> employeeList=new ArrayList<>();
	
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Transaction(LocalDate date, long transactionID, TransactionType transactionType, double transactionAmount,
			long beneficiaryAccountNumber, Account account, List<BankEmployee> employeeList) {
		super();
		this.date = date;
		this.transactionID = transactionID;
		this.transactionType = transactionType;
		this.transactionAmount = transactionAmount;
		this.beneficiaryAccountNumber = beneficiaryAccountNumber;
		this.account = account;
		this.employeeList = employeeList;
	}

	public LocalDate getDate() {
		return date;
	}
	public void setDate() {
		this.date = date.now();
	}
	public long getTransactionID() {
		return transactionID;
	}
	public void setTransactionID(long transactionID) {
		this.transactionID = transactionID;
	}
	public TransactionType getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(TransactionType transactionType) {
		this.transactionType = transactionType;
	}
	public double getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}
	
	public long getBeneficiaryAccountNumber() {
		return beneficiaryAccountNumber;
	}

	public void setBeneficiaryAccountNumber(long beneficiaryAccountNumber) {
		this.beneficiaryAccountNumber = beneficiaryAccountNumber;
	}

	@Override
	public String toString() {
		return "Transaction [date=" + date + ", transactionID=" + transactionID + ", transactionType=" + transactionType
				+ ", transactionAmount=" + transactionAmount + ", account=" + account + ", employeeList=" + employeeList
				+ "]";
	}
	
	
	
	
	

}
