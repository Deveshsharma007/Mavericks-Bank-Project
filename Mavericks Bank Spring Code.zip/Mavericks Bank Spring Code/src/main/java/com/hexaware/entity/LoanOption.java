package com.hexaware.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="loan_option")
public class LoanOption {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long loanOptionId;
	private String loanName;
	private double interestRate;
	public LoanOption() {
		super();
		// TODO Auto-generated constructor stub
	}
	public LoanOption(long loanOptionId, String loanName, double interestRate) {
		super();
		this.loanOptionId = loanOptionId;
		this.loanName = loanName;
		this.interestRate = interestRate;
	}
	public long getLoanOptionId() {
		return loanOptionId;
	}
	public void setLoanOptionId(long loanOptionId) {
		this.loanOptionId = loanOptionId;
	}
	public String getLoanName() {
		return loanName;
	}
	public void setLoanName(String loanName) {
		this.loanName = loanName;
	}
	public double getInterestRate() {
		return interestRate;
	}
	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}
	@Override
	public String toString() {
		return "LoanOption [loanOptionId=" + loanOptionId + ", loanName=" + loanName + ", interestRate=" + interestRate
				+ "]";
	}
	

}
