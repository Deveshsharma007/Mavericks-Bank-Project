package com.hexaware.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class OtherBankDetails {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long otherBankId;
	private String otherBankName;
	private String otherBankBranch;
	private String otherIFSCCode;
	public OtherBankDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public OtherBankDetails(long otherBankId, String otherBankName, String otherBankBranch, String otherIFSCCode) {
		super();
		this.otherBankId = otherBankId;
		this.otherBankName = otherBankName;
		this.otherBankBranch = otherBankBranch;
		this.otherIFSCCode = otherIFSCCode;
	}

	public long getOtherBankId() {
		return otherBankId;
	}

	public void setOtherBankId(long otherBankId) {
		this.otherBankId = otherBankId;
	}

	public String getOtherBankName() {
		return otherBankName;
	}

	public void setOtherBankName(String otherBankName) {
		this.otherBankName = otherBankName;
	}

	public String getOtherBankBranch() {
		return otherBankBranch;
	}

	public void setOtherBankBranch(String otherBankBranch) {
		this.otherBankBranch = otherBankBranch;
	}

	public String getOtherIFSCCode() {
		return otherIFSCCode;
	}

	public void setOtherIFSCCode(String otherIFSCCode) {
		this.otherIFSCCode = otherIFSCCode;
	}

	@Override
	public String toString() {
		return "OtherBankDetails [otherBankId=" + otherBankId + ", otherBankName=" + otherBankName
				+ ", otherBankBranch=" + otherBankBranch + ", otherIFSCCode=" + otherIFSCCode + "]";
	}

	
	
	

}
