package com.hexaware.dto;
//getting other bank name
public class OtherBankNameDTO {
	public OtherBankNameDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	private String otherBankName;

	public OtherBankNameDTO(String otherBankName) {
		super();
		this.otherBankName = otherBankName;
	}

	public String getOtherBankName() {
		return otherBankName;
	}

	public void setOtherBankName(String otherBankName) {
		this.otherBankName = otherBankName;
	}

	@Override
	public String toString() {
		return "OtherBankNameDTO [otherBankName=" + otherBankName + "]";
	}
	

}
