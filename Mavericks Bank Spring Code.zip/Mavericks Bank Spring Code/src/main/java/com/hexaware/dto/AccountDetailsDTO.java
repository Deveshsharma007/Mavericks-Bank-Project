package com.hexaware.dto;
//Display account details according to the account number
public class AccountDetailsDTO {

	   private String name;
    private long accountNumber;
    private String ifscCode;
    private String branchName;
    private double balance;
 

    // Additional details from the associated bank entity
    private String bankName;
    private String bankCity;
    private String bankState;
    
    
	public AccountDetailsDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AccountDetailsDTO(long accountNumber, String ifscCode, String branchName, double balance, String name,
			String bankName, String bankCity, String bankState) {
		super();
		this.accountNumber = accountNumber;
		this.ifscCode = ifscCode;
		this.branchName = branchName;
		this.balance = balance;
		this.name = name;
		this.bankName = bankName;
		this.bankCity = bankCity;
		this.bankState = bankState;
	}
	

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankCity() {
		return bankCity;
	}

	public void setBankCity(String bankCity) {
		this.bankCity = bankCity;
	}

	public String getBankState() {
		return bankState;
	}

	public void setBankState(String bankState) {
		this.bankState = bankState;
	}

	@Override
	public String toString() {
		return "AccountDetailsDTO [name=" + name + ", accountNumber=" + accountNumber + ", ifscCode=" + ifscCode
				+ ", branchName=" + branchName + ", balance=" + balance + ", bankName=" + bankName + ", bankCity="
				+ bankCity + ", bankState=" + bankState + "]";
	}
	
}

	