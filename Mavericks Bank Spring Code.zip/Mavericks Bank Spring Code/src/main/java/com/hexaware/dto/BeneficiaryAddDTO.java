package com.hexaware.dto;
//Beneficiary add 
import jakarta.validation.constraints.NotNull;

public class BeneficiaryAddDTO {
	@NotNull
	private long beneficiaryAccountNumber;
	@NotNull
	private String beneficiaryName;
	public BeneficiaryAddDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BeneficiaryAddDTO(long beneficiaryAccountNumber, String beneficiaryName) {
		super();
		this.beneficiaryAccountNumber = beneficiaryAccountNumber;
		this.beneficiaryName = beneficiaryName;
	}
	public long getBeneficiaryAccountNumber() {
		return beneficiaryAccountNumber;
	}
	public void setBeneficiaryAccountNumber(long beneficiaryAccountNumber) {
		this.beneficiaryAccountNumber = beneficiaryAccountNumber;
	}
	public String getBeneficiaryName() {
		return beneficiaryName;
	}
	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}
	@Override
	public String toString() {
		return "BeneficiaryAddDTO [beneficiaryAccountNumber=" + beneficiaryAccountNumber + ", beneficiaryName="
				+ beneficiaryName + "]";
	}
	

}
