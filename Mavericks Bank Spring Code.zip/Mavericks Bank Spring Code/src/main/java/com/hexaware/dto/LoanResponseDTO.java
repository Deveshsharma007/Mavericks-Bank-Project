package com.hexaware.dto;
//loan display 
import com.hexaware.enums.LoanStatus;

public class LoanResponseDTO {
	private long loanID;
	private double loanAmount;
	private double interestRate;
	private double tenure;
	private LoanStatus loanStatus;
	private String loanName;
	private long accountNumber;
	public LoanResponseDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public LoanResponseDTO(long loanID, double loanAmount, double interestRate, double tenure, LoanStatus loanStatus,
			String loanName, long accountNumber) {
		super();
		this.loanID = loanID;
		this.loanAmount = loanAmount;
		this.interestRate = interestRate;
		this.tenure = tenure;
		this.loanStatus = loanStatus;
		this.loanName = loanName;
		this.accountNumber = accountNumber;
	}
	public long getLoanID() {
		return loanID;
	}
	public void setLoanID(long loanID) {
		this.loanID = loanID;
	}
	public double getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}
	public double getInterestRate() {
		return interestRate;
	}
	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}
	public double getTenure() {
		return tenure;
	}
	public void setTenure(double tenure) {
		this.tenure = tenure;
	}
	public LoanStatus getLoanStatus() {
		return loanStatus;
	}
	public void setLoanStatus(LoanStatus loanStatus) {
		this.loanStatus = loanStatus;
	}
	public String getLoanName() {
		return loanName;
	}
	public void setLoanName(String loanName) {
		this.loanName = loanName;
	}
	public long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	@Override
	public String toString() {
		return "LoanResponseDTO [loanID=" + loanID + ", loanAmount=" + loanAmount + ", interestRate=" + interestRate
				+ ", tenure=" + tenure + ", loanStatus=" + loanStatus + ", loanName=" + loanName + ", accountNumber="
				+ accountNumber + "]";
	}
	
}	