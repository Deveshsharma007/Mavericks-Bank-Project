package com.hexaware.dto;
//Display list of account details
import com.hexaware.entity.Customer;
import com.hexaware.enums.AccountStatus;


public class AccountDisplayDTO {
	
	private long accountNumber;
	private String accountType;
	private double accountBalance;
	private AccountStatus accountStatus;
	private long customerId;
	private String customerName;
	public AccountDisplayDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AccountDisplayDTO(long accountNumber, String accountType, double accountBalance, AccountStatus accountStatus,
			long customerId, String customerName) {
		super();
		this.accountNumber = accountNumber;
		this.accountType = accountType;
		this.accountBalance = accountBalance;
		this.accountStatus = accountStatus;
		this.customerId = customerId;
		this.customerName = customerName;
	}
	public long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	public AccountStatus getAccountStatus() {
		return accountStatus;
	}
	public void setAccountStatus(AccountStatus accountStatus) {
		this.accountStatus = accountStatus;
	}
	public long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	@Override
	public String toString() {
		return "AccountDisplayDTO [accountNumber=" + accountNumber + ", accountType=" + accountType
				+ ", accountBalance=" + accountBalance + ", accountStatus=" + accountStatus + ", customerId="
				+ customerId + ", customerName=" + customerName + "]";
	}
	
}
	