package com.hexaware.dto;
public class UserDto {
	private String name;
	private String username;
	private String email;
	private String role;
	private long customerId;
	public UserDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public UserDto(String name, String username, String email, String role, long customerId) {
		super();
		this.name = name;
		this.username = username;
		this.email = email;
		this.role = role;
		this.customerId = customerId;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	@Override
	public String toString() {
		return "UserDto [name=" + name + ", username=" + username + ", email=" + email + ", role=" + role
				+ ", customerId=" + customerId + "]";
	}

	
 
}