package com.hexaware.service;

import java.util.List;

import com.hexaware.customexceptions.ResourceNotFoundException;
import com.hexaware.dto.AccountDetailsDTO;
import com.hexaware.dto.AccountDisplayDTO;
import com.hexaware.dto.AccountRequestDTO;
import com.hexaware.dto.LoanDTO;
import com.hexaware.dto.LoanResponseDTO;
import com.hexaware.entity.Account;

public interface AccountService {
	public Account addCustomer(Account account);
	public List<AccountDisplayDTO> displayAllAccounts ();
	List<AccountDisplayDTO>findAllAccountsOfCustomer(long customer_id) throws ResourceNotFoundException;
	public String deleteAccount(long id);
	public AccountDetailsDTO getAccountDetails(long accountId) throws ResourceNotFoundException;
	public String addAccount(long customerid,String accountRequest) throws ResourceNotFoundException;
	public String applyLoan(long accountnumber,String loanname,double interest,LoanDTO loan) throws ResourceNotFoundException;
	public List<LoanResponseDTO> appliedloan(long accountnumber) throws ResourceNotFoundException;
	public String deleteRequest(long accountnumber) throws ResourceNotFoundException;


}
