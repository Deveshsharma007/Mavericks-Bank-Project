package com.hexaware.service;

import java.time.LocalDate;
import java.util.List;

import com.hexaware.customexceptions.LessBalanceException;
import com.hexaware.customexceptions.ResourceNotFoundException;
import com.hexaware.dto.AllTransactionDTO;
import com.hexaware.dto.TransactionDepositDTO;
import com.hexaware.dto.TransactionTransferDTO;

public interface TransactionService {
	public String transferAmount(long accountnumber, TransactionTransferDTO transaction)
			throws ResourceNotFoundException, LessBalanceException;

	String depositAmount(long accountnumber, TransactionDepositDTO transaction) throws ResourceNotFoundException;

	String withdrawAmount(long accountnumber, TransactionDepositDTO transaction) throws ResourceNotFoundException, LessBalanceException;
	
	public List<AllTransactionDTO> view10Transaction(long accountnumber);
	
	public List<AllTransactionDTO>TransactionBetweenTwoDates(long accountnumber,LocalDate startdate,LocalDate enddate);
	
	public List<AllTransactionDTO>TransactionForLastMonth(long accountnumber,LocalDate startdate);

}
