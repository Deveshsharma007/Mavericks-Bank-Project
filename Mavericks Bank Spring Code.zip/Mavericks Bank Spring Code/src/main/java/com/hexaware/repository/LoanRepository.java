package com.hexaware.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hexaware.entity.Loan;

public interface LoanRepository extends JpaRepository<Loan,Long>{
	

}
