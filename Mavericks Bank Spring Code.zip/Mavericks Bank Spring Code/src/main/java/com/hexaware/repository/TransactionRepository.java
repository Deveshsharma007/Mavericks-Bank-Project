package com.hexaware.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hexaware.entity.Transaction;

public interface TransactionRepository extends JpaRepository<Transaction,Long>{
	
	@Query(value="select * from transaction t where t.account_account_number=:accountnumber order by t.transactionid desc limit 10",nativeQuery=true)
	List<Transaction> view10Transaction(long accountnumber);
	
	@Query(value="select * from transaction t where t.account_account_number=:accountnumber and t.date between :startdate and :enddate order by t.transactionid desc",nativeQuery=true)
	List<Transaction> TransactionBetweenTwoDates(long accountnumber,LocalDate startdate,LocalDate enddate);
	
	@Query(value="select * from transaction t where t.account_account_number=:accountnumber and t.date >= :startdate order by t.transactionid desc",nativeQuery=true)
	List<Transaction>TransactionForLastMonth(long accountnumber,LocalDate startdate);

}
