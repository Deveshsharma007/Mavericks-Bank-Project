package com.hexaware.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hexaware.entity.OtherBankDetails;

public interface OtherBankDetailRepository extends JpaRepository<OtherBankDetails,Long>{
	@Query(value="SELECT DISTINCT (o.other_bank_name) FROM other_bank_details o WHERE o.other_bank_name LIKE CONCAT(:name,'%')",nativeQuery=true)
	public List<String> findByotherBankNameContaining(String name);
	
	@Query(value="select other_bank_branch from other_bank_details where other_bank_name=:bankname",nativeQuery=true)
	public List<String> findBankBranch(String bankname);
	
	@Query(value="select otherifsccode from other_bank_details where other_bank_name=:bankname and other_bank_branch=:branchname",nativeQuery=true)
	public String getIfsccode(String bankname,String branchname);

}
