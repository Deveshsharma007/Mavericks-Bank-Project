package com.hexaware.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hexaware.entity.Bank;

public interface BankRepository extends JpaRepository <Bank,Long> {
	

}
