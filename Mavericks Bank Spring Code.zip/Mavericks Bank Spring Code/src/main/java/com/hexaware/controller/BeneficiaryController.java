package com.hexaware.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hexaware.customexceptions.ResourceNotFoundException;
import com.hexaware.dto.BeneficiaryAddDTO;
import com.hexaware.service.BeneficiaryService;

import jakarta.validation.Valid;

@CrossOrigin("*")
@RestController
@RequestMapping("/api/beneficiary")
public class BeneficiaryController {
	
	@Autowired
	private BeneficiaryService beneficiaryService;
	
	@PreAuthorize("hasAuthority('ROLE_USER')")
	@PostMapping("/{accountid}/{bankname}/{bankbranch}/{ifsc}")
	public ResponseEntity<String> addBeneficiary(@PathVariable long accountid,@PathVariable String bankname,@PathVariable String bankbranch,@PathVariable String ifsc,@Valid @RequestBody BeneficiaryAddDTO beneficiary) throws ResourceNotFoundException
	{
		return ResponseEntity.ok(beneficiaryService.addBeneficiary(accountid, bankname, bankbranch, ifsc, beneficiary));
		
	}

}
