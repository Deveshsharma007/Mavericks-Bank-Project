package com.hexaware.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hexaware.customexceptions.ResourceNotFoundException;
import com.hexaware.dto.BeneficiaryAddDTO;
import com.hexaware.dto.OtherBankDetailsAddDTO;
import com.hexaware.service.BeneficiaryService;
import com.hexaware.service.OtherBankDetailService;

import jakarta.validation.Valid;

@CrossOrigin("*")
@RestController
@RequestMapping("/api/v1/otherbankdetails")
public class OtherBankDetailController {
	private OtherBankDetailService otherService;
	@Autowired
	private BeneficiaryService beneficiaryService;

	public OtherBankDetailController(OtherBankDetailService otherService) {
		super();
		this.otherService = otherService;
	}
	
	@PostMapping("/addotherbank")
	public ResponseEntity<OtherBankDetailsAddDTO> addOtherBank(@Valid @RequestBody OtherBankDetailsAddDTO otherBank)
	{
		return ResponseEntity.ok(otherService.addOtherBank(otherBank));
	}
	
	@GetMapping("/findbybankname/{bankname}")
	public ResponseEntity<List<String>> findByotherBankNameContaining(@PathVariable String bankname){
			return ResponseEntity.ok(otherService.findByotherBankNameContaining(bankname));	
		
	}
	@GetMapping("/{bankname}")
	public ResponseEntity<List<String>> findBankBranch(@PathVariable String bankname)
	{
		return ResponseEntity.ok(otherService.findBankBranch(bankname));
		
	}
	@GetMapping("/{bankname}/{branchname}")
	public ResponseEntity <String> getBankIfsccode(@PathVariable String bankname,@PathVariable String branchname)
	{
		return ResponseEntity.ok(otherService.getIfsccode(bankname,branchname));	
	}
	
	@PreAuthorize("hasAuthority('ROLE_USER')")
	@GetMapping("/getbeneficiary/{accountnumber}")
	public ResponseEntity<List<BeneficiaryAddDTO>> getBeneficiary(@PathVariable long accountnumber) throws ResourceNotFoundException
	{
		return ResponseEntity.ok(beneficiaryService.getBeneficiary(accountnumber));
	}
	

}
