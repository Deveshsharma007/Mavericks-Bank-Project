package com.hexaware.controller;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hexaware.customexceptions.ResourceNotFoundException;
import com.hexaware.dto.AccountDetailsDTO;
import com.hexaware.dto.AccountDisplayDTO;
import com.hexaware.dto.LoanDTO;
import com.hexaware.dto.LoanResponseDTO;
import com.hexaware.service.AccountService;
import com.hexaware.service.CustomerService;

import jakarta.validation.Valid;

@CrossOrigin("*")
@RestController
@RequestMapping("/api/v1/bankapp/Customer")
public class AccountController {
	private AccountService accountService;

	private CustomerService customerService;
	
	@Autowired
	public void setAccountService(AccountService accountService) {
		this.accountService = accountService;
	}
    @Autowired
	public void setCustomerService(CustomerService customerService) {
		this.customerService = customerService;
	}
	

	public final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	
	@PreAuthorize("hasAuthority('ROLE_ADMIN') or hasAuthority('ROLE_EMP')")
	@GetMapping("/displayallaccount")
	public ResponseEntity<List<AccountDisplayDTO>> displayAllAccounts()
	{
		
		return ResponseEntity.ok(accountService.displayAllAccounts());
	}
	
	@PreAuthorize("hasAuthority('ROLE_ADMIN') or hasAuthority('ROLE_EMP') or hasAuthority('ROLE_USER')")
	@GetMapping("/findaccount/{customer_id}")
	public ResponseEntity<List<AccountDisplayDTO>>findAllAccountsOfCustomer(@PathVariable long customer_id) throws ResourceNotFoundException
	{
		return ResponseEntity.ok(accountService.findAllAccountsOfCustomer(customer_id));
	}
	
	@PreAuthorize("hasAuthority('ROLE_ADMIN') or hasAuthority('ROLE_EMP') or hasAuthority('ROLE_USER')")
	@GetMapping("/{accountId}")
    public ResponseEntity<AccountDetailsDTO> getAccountDetails(@PathVariable long accountId) {
        try {
            AccountDetailsDTO accountDetails = accountService.getAccountDetails(accountId);
            return new ResponseEntity<>(accountDetails, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
	
	@PreAuthorize("hasAuthority('ROLE_USER')")
	@PostMapping("/add/{customerid}/{accountRequest}")
    public ResponseEntity<String> addAccount(@PathVariable long customerid,@PathVariable String accountRequest) throws ResourceNotFoundException {
       
            return ResponseEntity.ok(accountService.addAccount(customerid,accountRequest));   
    }
	
	@PreAuthorize("hasAuthority('ROLE_USER')")
	@PostMapping("/{accountnumber}/applyloan/{loanname}/{interest}")
	 public ResponseEntity<String> applyLoan(@PathVariable long accountnumber ,@PathVariable String loanname,@PathVariable double interest,@Valid @RequestBody LoanDTO loan) throws ResourceNotFoundException {
	       
        return ResponseEntity.ok(accountService.applyLoan(accountnumber,loanname,interest,loan));
	}
	
	@PreAuthorize("hasAuthority('ROLE_USER')")
	@GetMapping("/{accountnumber}/getloan")
	public ResponseEntity<List<LoanResponseDTO>> appliedloan(@PathVariable long accountnumber) throws ResourceNotFoundException{
		return ResponseEntity.ok(accountService.appliedloan(accountnumber));
		
	}
	
	@PreAuthorize("hasAuthority('ROLE_USER')")
	@GetMapping("/deleterequest/{accountnumber}")
	public ResponseEntity<String> deleteRequest(@PathVariable long accountnumber) throws ResourceNotFoundException{
		return ResponseEntity.ok(accountService.deleteRequest(accountnumber));
		
	}	

}


