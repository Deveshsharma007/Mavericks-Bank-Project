package com.hexaware.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hexaware.customexceptions.AccountAlreadyExistsException;
import com.hexaware.customexceptions.ResourceNotFoundException;
import com.hexaware.dto.AllTransactionDTO;
import com.hexaware.dto.BankEmployeeAddDTO;
import com.hexaware.dto.InOutDTO;
import com.hexaware.dto.LoanResponseDTO;
import com.hexaware.entity.LoanOption;
import com.hexaware.service.BankEmployeeService;
import com.hexaware.service.BankService;

import jakarta.validation.Valid;

@CrossOrigin("*")
@RestController
@RequestMapping("/api/v1/bank/bankemp")
public class BankEmployeeController {

	private BankEmployeeService bankEmployeeService;
	private BankService bankService;

	public BankEmployeeController(BankEmployeeService bankEmployeeService, BankService bankService) {
		super();
		this.bankEmployeeService = bankEmployeeService;
		this.bankService = bankService;
	}

	@PostMapping("/addloandetails")
	public ResponseEntity<LoanOption> addLoanOptionDetails(@RequestBody LoanOption loanoption) {
		return ResponseEntity.ok(bankEmployeeService.addLoanOptionDetails(loanoption));
	}

	@PreAuthorize("hasAuthority('ROLE_ADMIN') or hasAuthority('ROLE_EMP')")
	@GetMapping("/activateaccount/{accountnumber}")
	public ResponseEntity<String> activateAccount(@PathVariable long accountnumber) throws ResourceNotFoundException {
		return ResponseEntity.ok(bankEmployeeService.activateAccount(accountnumber));
	}

	@PreAuthorize("hasAuthority('ROLE_ADMIN') or hasAuthority('ROLE_EMP')")
	@GetMapping("/closeaccount/{accountnumber}")
	public ResponseEntity<String> closeAccount(@PathVariable long accountnumber) throws ResourceNotFoundException {
		return ResponseEntity.ok(bankEmployeeService.closeAccount(accountnumber));
	}

	@PreAuthorize("hasAuthority('ROLE_EMP')")
	@GetMapping("/alltransaction")
	public ResponseEntity<List<AllTransactionDTO>> allTransaction() {
		return ResponseEntity.ok(bankEmployeeService.allTransaction());
	}

	@PreAuthorize("hasAuthority('ROLE_ADMIN') or hasAuthority('ROLE_EMP') or hasAuthority('ROLE_USER')")
	@GetMapping("/transactionofaccount/{accountnumber}")
	public ResponseEntity<List<AllTransactionDTO>> allTransactionOfAccount(@PathVariable long accountnumber)
			throws ResourceNotFoundException {

		return ResponseEntity.ok(bankEmployeeService.allTransactionOfAccount(accountnumber));
	}

	@PreAuthorize("hasAuthority('ROLE_ADMIN') or hasAuthority('ROLE_EMP') or hasAuthority('ROLE_USER')")
	@GetMapping("/inoutbound/{accountnumber}")
	public ResponseEntity<InOutDTO> totalCalculation(@PathVariable long accountnumber)
			throws ResourceNotFoundException {
		return ResponseEntity.ok(bankEmployeeService.totalCalculation(accountnumber));
	}

	@PreAuthorize("hasAuthority('ROLE_ADMIN') or hasAuthority('ROLE_EMP')")
	@GetMapping("/allloanapplication")
	public ResponseEntity<List<LoanResponseDTO>> allLoanApplications() {
		return ResponseEntity.ok(bankEmployeeService.allLoanApplications());
	}

	@PreAuthorize("hasAuthority('ROLE_ADMIN') or hasAuthority('ROLE_EMP')")
	@GetMapping("/loanapproval/{LoanId}")
	public ResponseEntity<String> loanApproval(@PathVariable long LoanId) throws ResourceNotFoundException {
		return ResponseEntity.ok(bankEmployeeService.loanApproval(LoanId));
	}
	
	@PreAuthorize("hasAuthority('ROLE_ADMIN') or hasAuthority('ROLE_EMP')")
	@GetMapping("/loanreject/{LoanId}")
	public ResponseEntity<String> loanReject(@PathVariable long LoanId) throws ResourceNotFoundException{
		return ResponseEntity.ok(bankEmployeeService.loanReject(LoanId));
		
	}

}
