package com.hexaware.customexceptions;

public class LessBalanceException extends Exception{
	private String message;
	public LessBalanceException(String message) {
		super(message);
		this.message = message;
	}
	

}